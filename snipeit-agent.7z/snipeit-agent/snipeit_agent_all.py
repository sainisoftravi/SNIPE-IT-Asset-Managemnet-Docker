#!/usr/bin/env python3
"""
Snipe-IT Agent - All-in-One Script
A comprehensive script that handles everything:
- System information collection
- Device type detection
- Snipe-IT API integration
- Asset management
- Testing and diagnostics
"""

import json
import logging
import os
import platform
import psutil
import requests
import socket
import subprocess
import sys
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List
import argparse

class SnipeITAgent:
    def __init__(self, config_path: str = "config.json"):
        """Initialize the Snipe-IT Agent."""
        self.config_path = config_path
        self.config = self.load_config()
        self.setup_logging()
        self.session = requests.Session()
        self.session.headers.update({
            'Authorization': f"Bearer {self.config['snipeit']['api_token']}",
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        })
        
    def load_config(self) -> Dict[str, Any]:
        """Load configuration from JSON file."""
        try:
            with open(self.config_path, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            print(f"ERROR: Configuration file {self.config_path} not found")
            sys.exit(1)
        except json.JSONDecodeError as e:
            print(f"ERROR: Invalid JSON in configuration file: {e}")
            sys.exit(1)
    
    def setup_logging(self):
        """Setup logging configuration."""
        log_level = getattr(logging, self.config['agent']['log_level'].upper())
        logging.basicConfig(
            level=log_level,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(self.config['agent']['log_file']),
                logging.StreamHandler(sys.stdout)
            ]
        )
        self.logger = logging.getLogger(__name__)
    
    def collect_system_info(self) -> Dict[str, Any]:
        """Collect comprehensive system information."""
        self.logger.info("Collecting system information...")
        
        system_info = {
            'timestamp': datetime.now().isoformat(),
            'platform': platform.platform(),
            'system': platform.system(),
            'release': platform.release(),
            'version': platform.version(),
            'machine': platform.machine(),
            'processor': platform.processor(),
            'hostname': socket.gethostname(),
            'fqdn': socket.getfqdn(),
            'hardware': self.collect_hardware_info(),
            'network': self.collect_network_info(),
            'storage': self.collect_storage_info(),
            'memory': self.collect_memory_info(),
            'cpu': self.collect_cpu_info(),
            'bios': self.collect_bios_info(),
            'software': self.collect_software_info()
        }
        
        return system_info
    
    def collect_hardware_info(self) -> Dict[str, Any]:
        """Collect hardware information."""
        if not self.config['collection']['hardware']:
            return {}
            
        hardware = {
            'cpu_count': psutil.cpu_count(),
            'cpu_count_logical': psutil.cpu_count(logical=True),
            'boot_time': datetime.fromtimestamp(psutil.boot_time()).isoformat(),
            'uptime': time.time() - psutil.boot_time()
        }
        
        # Try to get more detailed hardware info
        try:
            if platform.system() == "Windows":
                hardware.update(self.get_windows_hardware_info())
            elif platform.system() == "Linux":
                hardware.update(self.get_linux_hardware_info())
            elif platform.system() == "Darwin":
                hardware.update(self.get_macos_hardware_info())
        except Exception as e:
            self.logger.warning(f"Could not collect detailed hardware info: {e}")
        
        # Detect device type (desktop/laptop)
        hardware['device_type'] = self.detect_device_type(hardware)
        
        return hardware
    
    def detect_device_type(self, hardware: Dict[str, Any]) -> str:
        """Detect if the device is a desktop or laptop."""
        try:
            if platform.system() == "Windows":
                return self.detect_windows_device_type(hardware)
            elif platform.system() == "Linux":
                return self.detect_linux_device_type(hardware)
            elif platform.system() == "Darwin":
                return self.detect_macos_device_type(hardware)
            else:
                return "unknown"
        except Exception as e:
            self.logger.warning(f"Could not detect device type: {e}")
            return "unknown"
    
    def detect_windows_device_type(self, hardware: Dict[str, Any]) -> str:
        """Detect Windows device type (desktop/laptop)."""
        try:
            import wmi
            c = wmi.WMI()
            
            # Check for battery presence (laptops usually have batteries)
            batteries = c.Win32_Battery()
            if batteries:
                self.logger.info("Battery detected - likely a laptop")
                return "laptop"
            
            # Check chassis type
            for chassis in c.Win32_SystemEnclosure():
                chassis_type = chassis.ChassisTypes[0] if chassis.ChassisTypes else 0
                # Chassis types: 8=Laptop, 9=Notebook, 10=Handheld, 3=Desktop, 4=Low Profile Desktop
                if chassis_type in [8, 9, 10]:
                    self.logger.info(f"Chassis type {chassis_type} detected - laptop")
                    return "laptop"
                elif chassis_type in [3, 4]:
                    self.logger.info(f"Chassis type {chassis_type} detected - desktop")
                    return "desktop"
            
            # Check model name for laptop indicators
            model = hardware.get('model', '').lower()
            laptop_keywords = ['laptop', 'notebook', 'latitude', 'inspiron', 'precision', 'xps', 'thinkpad', 'ideapad', 'pavilion', 'envy']
            desktop_keywords = ['desktop', 'optiplex', 'precision tower', 'workstation']
            
            for keyword in laptop_keywords:
                if keyword in model:
                    self.logger.info(f"Model '{model}' contains laptop keyword '{keyword}'")
                    return "laptop"
            
            for keyword in desktop_keywords:
                if keyword in model:
                    self.logger.info(f"Model '{model}' contains desktop keyword '{keyword}'")
                    return "desktop"
            
            # Default to desktop if we can't determine
            self.logger.info("Could not determine device type, defaulting to desktop")
            return "desktop"
            
        except ImportError:
            self.logger.warning("WMI not available, using model name detection")
            model = hardware.get('model', '').lower()
            laptop_keywords = ['laptop', 'notebook', 'latitude', 'inspiron', 'precision', 'xps', 'thinkpad', 'ideapad', 'pavilion', 'envy']
            for keyword in laptop_keywords:
                if keyword in model:
                    return "laptop"
            return "desktop"
        except Exception as e:
            self.logger.warning(f"Error detecting Windows device type: {e}")
            return "desktop"
    
    def detect_linux_device_type(self, hardware: Dict[str, Any]) -> str:
        """Detect Linux device type (desktop/laptop)."""
        try:
            # Check for battery
            import os
            if os.path.exists('/sys/class/power_supply/BAT0'):
                self.logger.info("Battery detected - likely a laptop")
                return "laptop"
            
            # Check DMI chassis type
            try:
                with open('/sys/devices/virtual/dmi/id/chassis_type', 'r') as f:
                    chassis_type = int(f.read().strip())
                    # Chassis types: 8=Laptop, 9=Notebook, 10=Handheld, 3=Desktop, 4=Low Profile Desktop
                    if chassis_type in [8, 9, 10]:
                        return "laptop"
                    elif chassis_type in [3, 4]:
                        return "desktop"
            except (FileNotFoundError, ValueError):
                pass
            
            # Check model name
            model = hardware.get('model', '').lower()
            laptop_keywords = ['laptop', 'notebook', 'latitude', 'inspiron', 'precision', 'xps', 'thinkpad', 'ideapad', 'pavilion', 'envy']
            for keyword in laptop_keywords:
                if keyword in model:
                    return "laptop"
            
            return "desktop"
            
        except Exception as e:
            self.logger.warning(f"Error detecting Linux device type: {e}")
            return "desktop"
    
    def detect_macos_device_type(self, hardware: Dict[str, Any]) -> str:
        """Detect macOS device type (desktop/laptop)."""
        try:
            # Check for battery
            result = subprocess.run(['pmset', '-g', 'batt'], capture_output=True, text=True, timeout=10)
            if result.returncode == 0 and 'Battery' in result.stdout:
                self.logger.info("Battery detected - likely a laptop")
                return "laptop"
            
            # Check model name
            model = hardware.get('model', '').lower()
            laptop_keywords = ['macbook', 'macbook air', 'macbook pro']
            desktop_keywords = ['imac', 'mac pro', 'mac mini', 'mac studio']
            
            for keyword in laptop_keywords:
                if keyword in model:
                    return "laptop"
            
            for keyword in desktop_keywords:
                if keyword in model:
                    return "desktop"
            
            return "desktop"
            
        except Exception as e:
            self.logger.warning(f"Error detecting macOS device type: {e}")
            return "desktop"
    
    def get_windows_hardware_info(self) -> Dict[str, Any]:
        """Get Windows-specific hardware information."""
        hardware = {}
        
        try:
            # Get system information using WMI
            import wmi
            c = wmi.WMI()
            
            # Computer system info
            for system in c.Win32_ComputerSystem():
                hardware['manufacturer'] = system.Manufacturer
                hardware['model'] = system.Model
                hardware['total_physical_memory'] = system.TotalPhysicalMemory
            
            # BIOS info
            for bios in c.Win32_BIOS():
                hardware['bios_version'] = bios.Version
                hardware['bios_manufacturer'] = bios.Manufacturer
                hardware['serial_number'] = bios.SerialNumber
            
            # Processor info
            for processor in c.Win32_Processor():
                hardware['cpu_name'] = processor.Name
                hardware['cpu_manufacturer'] = processor.Manufacturer
                hardware['cpu_max_clock_speed'] = processor.MaxClockSpeed
                
        except ImportError:
            self.logger.warning("WMI module not available, using basic hardware detection")
        except Exception as e:
            self.logger.warning(f"Error getting Windows hardware info: {e}")
        
        return hardware
    
    def get_linux_hardware_info(self) -> Dict[str, Any]:
        """Get Linux-specific hardware information."""
        hardware = {}
        
        try:
            # Get system information from /sys and /proc
            with open('/sys/devices/virtual/dmi/id/product_name', 'r') as f:
                hardware['model'] = f.read().strip()
            
            with open('/sys/devices/virtual/dmi/id/sys_vendor', 'r') as f:
                hardware['manufacturer'] = f.read().strip()
                
            with open('/sys/devices/virtual/dmi/id/product_serial', 'r') as f:
                hardware['serial_number'] = f.read().strip()
                
        except Exception as e:
            self.logger.warning(f"Error getting Linux hardware info: {e}")
        
        return hardware
    
    def get_macos_hardware_info(self) -> Dict[str, Any]:
        """Get macOS-specific hardware information."""
        hardware = {}
        
        try:
            # Get system information using system_profiler
            result = subprocess.run(['system_profiler', 'SPHardwareDataType', '-json'], 
                                  capture_output=True, text=True, timeout=30)
            if result.returncode == 0:
                data = json.loads(result.stdout)
                if 'SPHardwareDataType' in data and len(data['SPHardwareDataType']) > 0:
                    hw_data = data['SPHardwareDataType'][0]
                    hardware['model'] = hw_data.get('model_name', '')
                    hardware['manufacturer'] = 'Apple'
                    hardware['serial_number'] = hw_data.get('serial_number', '')
                    hardware['cpu_name'] = hw_data.get('cpu_type', '')
        except Exception as e:
            self.logger.warning(f"Error getting macOS hardware info: {e}")
        
        return hardware
    
    def collect_network_info(self) -> Dict[str, Any]:
        """Collect network information."""
        if not self.config['collection']['network']:
            return {}
            
        network = {
            'interfaces': [],
            'hostname': socket.gethostname(),
            'fqdn': socket.getfqdn()
        }
        
        try:
            # Get network interfaces
            for interface, addrs in psutil.net_if_addrs().items():
                interface_info = {
                    'name': interface,
                    'addresses': []
                }
                
                for addr in addrs:
                    interface_info['addresses'].append({
                        'family': str(addr.family),
                        'address': addr.address,
                        'netmask': addr.netmask,
                        'broadcast': addr.broadcast
                    })
                
                network['interfaces'].append(interface_info)
                
        except Exception as e:
            self.logger.warning(f"Error collecting network info: {e}")
        
        return network
    
    def collect_storage_info(self) -> Dict[str, Any]:
        """Collect storage information."""
        if not self.config['collection']['storage']:
            return {}
            
        storage = {
            'disks': []
        }
        
        try:
            # Get disk partitions
            for partition in psutil.disk_partitions():
                try:
                    partition_usage = psutil.disk_usage(partition.mountpoint)
                    storage['disks'].append({
                        'device': partition.device,
                        'mountpoint': partition.mountpoint,
                        'fstype': partition.fstype,
                        'total': partition_usage.total,
                        'used': partition_usage.used,
                        'free': partition_usage.free,
                        'percent': partition_usage.percent
                    })
                except PermissionError:
                    continue
                    
        except Exception as e:
            self.logger.warning(f"Error collecting storage info: {e}")
        
        return storage
    
    def collect_memory_info(self) -> Dict[str, Any]:
        """Collect memory information."""
        if not self.config['collection']['memory']:
            return {}
            
        memory = {}
        
        try:
            # Virtual memory
            vm = psutil.virtual_memory()
            memory['virtual'] = {
                'total': vm.total,
                'available': vm.available,
                'used': vm.used,
                'free': vm.free,
                'percent': vm.percent
            }
            
            # Swap memory
            swap = psutil.swap_memory()
            memory['swap'] = {
                'total': swap.total,
                'used': swap.used,
                'free': swap.free,
                'percent': swap.percent
            }
            
        except Exception as e:
            self.logger.warning(f"Error collecting memory info: {e}")
        
        return memory
    
    def collect_cpu_info(self) -> Dict[str, Any]:
        """Collect CPU information."""
        if not self.config['collection']['cpu']:
            return {}
            
        cpu = {}
        
        try:
            # CPU times
            cpu_times = psutil.cpu_times()
            cpu['times'] = {
                'user': cpu_times.user,
                'system': cpu_times.system,
                'idle': cpu_times.idle,
                'iowait': getattr(cpu_times, 'iowait', 0),
                'irq': getattr(cpu_times, 'irq', 0),
                'softirq': getattr(cpu_times, 'softirq', 0)
            }
            
            # CPU frequency
            try:
                cpu_freq = psutil.cpu_freq()
                cpu['frequency'] = {
                    'current': cpu_freq.current,
                    'min': cpu_freq.min,
                    'max': cpu_freq.max
                }
            except AttributeError:
                pass
                
            # CPU usage
            cpu['usage_percent'] = psutil.cpu_percent(interval=1)
            cpu['usage_per_cpu'] = psutil.cpu_percent(interval=1, percpu=True)
            
        except Exception as e:
            self.logger.warning(f"Error collecting CPU info: {e}")
        
        return cpu
    
    def collect_bios_info(self) -> Dict[str, Any]:
        """Collect BIOS information."""
        if not self.config['collection']['bios']:
            return {}
            
        bios = {}
        
        try:
            if platform.system() == "Windows":
                import wmi
                c = wmi.WMI()
                for bios_info in c.Win32_BIOS():
                    bios['version'] = bios_info.Version
                    bios['manufacturer'] = bios_info.Manufacturer
                    bios['release_date'] = bios_info.ReleaseDate
                    bios['serial_number'] = bios_info.SerialNumber
            elif platform.system() == "Linux":
                # Try to read from DMI
                try:
                    with open('/sys/devices/virtual/dmi/id/bios_version', 'r') as f:
                        bios['version'] = f.read().strip()
                    with open('/sys/devices/virtual/dmi/id/bios_vendor', 'r') as f:
                        bios['manufacturer'] = f.read().strip()
                    with open('/sys/devices/virtual/dmi/id/bios_date', 'r') as f:
                        bios['release_date'] = f.read().strip()
                except FileNotFoundError:
                    pass
        except Exception as e:
            self.logger.warning(f"Error collecting BIOS info: {e}")
        
        return bios
    
    def collect_software_info(self) -> Dict[str, Any]:
        """Collect software information."""
        if not self.config['collection']['software']:
            return {}
            
        software = {
            'python_version': sys.version,
            'platform_python_implementation': platform.python_implementation(),
            'platform_python_version': platform.python_version()
        }
        
        try:
            # Get running processes (limited to avoid performance issues)
            processes = []
            for proc in psutil.process_iter(['pid', 'name', 'username', 'cpu_percent', 'memory_percent']):
                try:
                    processes.append(proc.info)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
                if len(processes) >= 100:  # Limit to 100 processes
                    break
            
            software['running_processes'] = processes
            
        except Exception as e:
            self.logger.warning(f"Error collecting software info: {e}")
        
        return software
    
    def generate_asset_tag(self) -> str:
        """Generate a unique asset tag."""
        hostname = socket.gethostname()
        timestamp = datetime.now().strftime("%Y%m%d")
        unique_id = str(uuid.uuid4())[:8]
        return f"{hostname}-{timestamp}-{unique_id}"
    
    def create_concise_notes(self, system_info: Dict[str, Any], device_type: str) -> str:
        """Create concise notes with only important information."""
        notes_lines = [
            f"Auto-created by Snipe-IT Agent on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"Device Type: {device_type.title()}",
            ""
        ]
        
        # Add important hardware information
        hardware = system_info.get('hardware', {})
        if hardware:
            notes_lines.append("Hardware Information:")
            if hardware.get('manufacturer'):
                notes_lines.append(f"• Manufacturer: {hardware['manufacturer']}")
            if hardware.get('model'):
                notes_lines.append(f"• Model: {hardware['model']}")
            if hardware.get('serial_number'):
                notes_lines.append(f"• Serial: {hardware['serial_number']}")
            if hardware.get('cpu_name'):
                notes_lines.append(f"• CPU: {hardware['cpu_name']}")
            if hardware.get('total_physical_memory'):
                memory_gb = int(hardware['total_physical_memory']) / (1024**3)
                notes_lines.append(f"• RAM: {memory_gb:.1f} GB")
            if hardware.get('bios_version'):
                notes_lines.append(f"• BIOS: {hardware['bios_version']}")
            notes_lines.append("")
        
        # Add important system information
        notes_lines.append("System Information:")
        notes_lines.append(f"• OS: {system_info.get('platform', 'Unknown')}")
        notes_lines.append(f"• Hostname: {system_info.get('hostname', 'Unknown')}")
        if system_info.get('boot_time'):
                boot_time = datetime.fromisoformat(system_info['boot_time'].replace('Z', '+00:00'))
                notes_lines.append(f"• Boot Time: {boot_time.strftime('%Y-%m-%d %H:%M:%S')}")
        notes_lines.append("")
        
        # Add important network information (primary IP and MAC address)
        network = system_info.get('network', {})
        if network and network.get('interfaces'):
            primary_ip = None
            primary_mac = None
            
            # Look for Wi-Fi first, then Ethernet, then other connections
            interface_priority = ['wi-fi', 'ethernet', 'local area connection']
            
            for priority_name in interface_priority:
                for interface in network['interfaces']:
                    if priority_name in interface['name'].lower():
                        # Get MAC address (family -1)
                        for addr in interface['addresses']:
                            if addr['family'] == '-1' and len(addr['address']) == 17:  # MAC address format
                                primary_mac = addr['address']
                                break
                        
                        # Get IP address (family 2, not link-local)
                        for addr in interface['addresses']:
                            if addr['family'] == '2' and not addr['address'].startswith('169.254'):
                                primary_ip = addr['address']
                                break
                        
                        if primary_ip and primary_mac:
                            break
                
                if primary_ip and primary_mac:
                    break
            
            if primary_ip or primary_mac:
                notes_lines.append("Network Information:")
                if primary_ip:
                    notes_lines.append(f"• Primary IP: {primary_ip}")
                if primary_mac:
                    notes_lines.append(f"• MAC Address: {primary_mac}")
                notes_lines.append("")
        
        # Add important storage information
        storage = system_info.get('storage', {})
        if storage and storage.get('disks'):
            total_storage_gb = 0
            used_storage_gb = 0
            for disk in storage['disks']:
                total_storage_gb += disk['total'] / (1024**3)
                used_storage_gb += disk['used'] / (1024**3)
            
            if total_storage_gb > 0:
                notes_lines.append("Storage Information:")
                notes_lines.append(f"• Total Storage: {total_storage_gb:.1f} GB")
                notes_lines.append(f"• Used Storage: {used_storage_gb:.1f} GB")
                usage_percent = (used_storage_gb / total_storage_gb) * 100
                notes_lines.append(f"• Usage: {usage_percent:.1f}%")
                notes_lines.append("")
        
        # Add agent information
        notes_lines.append("Agent Information:")
        notes_lines.append("• Version: 1.0.0")
        notes_lines.append("• Last Updated: " + datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        
        return "\n".join(notes_lines)
    
    def find_existing_asset(self, system_info: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Find existing asset by hostname or serial number."""
        try:
            # Search by hostname
            response = self.session.get(
                f"{self.config['snipeit']['base_url']}/api/v1/hardware",
                params={'search': system_info['hostname']},
                timeout=self.config['snipeit']['timeout']
            )
            
            if response.status_code == 200:
                data = response.json()
                if data.get('total', 0) > 0:
                    return data['rows'][0]
            
            # Search by serial number if available
            serial = system_info.get('hardware', {}).get('serial_number')
            if serial:
                response = self.session.get(
                    f"{self.config['snipeit']['base_url']}/api/v1/hardware",
                    params={'serial': serial},
                    timeout=self.config['snipeit']['timeout']
                )
                
                if response.status_code == 200:
                    data = response.json()
                    if data.get('total', 0) > 0:
                        return data['rows'][0]
                        
        except Exception as e:
            self.logger.error(f"Error searching for existing asset: {e}")
        
        return None
    
    def get_model_for_device_type(self, device_type: str, system_info: Dict[str, Any]) -> Optional[int]:
        """Get the appropriate model ID based on device type."""
        try:
            # First, try to find an existing model that matches the device type
            manufacturer = system_info.get('hardware', {}).get('manufacturer', '')
            model_name = system_info.get('hardware', {}).get('model', '')
            
            # Search for existing models
            response = self.session.get(
                f"{self.config['snipeit']['base_url']}/api/v1/models",
                timeout=self.config['snipeit']['timeout']
            )
            
            if response.status_code == 200:
                data = response.json()
                models = data.get('rows', [])
                
                # Look for exact model match first
                for model in models:
                    if (model.get('name', '').lower() == model_name.lower() or 
                        model.get('model_number', '').lower() == model_name.lower()):
                        self.logger.info(f"Found exact model match: {model['name']} (ID: {model['id']})")
                        return model['id']
                
                # Look for device type specific models
                for model in models:
                    model_name_lower = model.get('name', '').lower()
                    if device_type == 'laptop':
                        laptop_keywords = ['laptop', 'notebook', 'latitude', 'inspiron', 'precision', 'xps', 'thinkpad', 'ideapad', 'pavilion', 'envy', 'macbook']
                        if any(keyword in model_name_lower for keyword in laptop_keywords):
                            self.logger.info(f"Found laptop model: {model['name']} (ID: {model['id']})")
                            return model['id']
                    elif device_type == 'desktop':
                        desktop_keywords = ['desktop', 'optiplex', 'precision tower', 'workstation', 'imac', 'mac pro', 'mac mini']
                        if any(keyword in model_name_lower for keyword in desktop_keywords):
                            self.logger.info(f"Found desktop model: {model['name']} (ID: {model['id']})")
                            return model['id']
                
                # If no specific match found, use the first available model
                if models:
                    self.logger.info(f"No specific model found, using first available: {models[0]['name']} (ID: {models[0]['id']})")
                    return models[0]['id']
            
            # If no models found, try to create one
            self.logger.info(f"No models found, attempting to create {device_type} model")
            return self.create_model_for_device_type(device_type, system_info)
            
        except Exception as e:
            self.logger.error(f"Error getting model for device type: {e}")
            return None
    
    def create_model_for_device_type(self, device_type: str, system_info: Dict[str, Any]) -> Optional[int]:
        """Create a new model for the device type."""
        try:
            manufacturer = system_info.get('hardware', {}).get('manufacturer', 'Unknown')
            model_name = system_info.get('hardware', {}).get('model', f'Generic {device_type.title()}')
            
            # Get or create manufacturer
            manufacturer_id = self.get_or_create_manufacturer(manufacturer)
            if not manufacturer_id:
                return None
            
            # Get or create category
            category_name = "Laptop" if device_type == 'laptop' else "Desktop"
            category_id = self.get_or_create_category(category_name)
            if not category_id:
                return None
            
            # Create model
            model_data = {
                'name': model_name,
                'manufacturer_id': manufacturer_id,
                'category_id': category_id,
                'model_number': model_name
            }
            
            response = self.session.post(
                f"{self.config['snipeit']['base_url']}/api/v1/models",
                json=model_data,
                timeout=self.config['snipeit']['timeout']
            )
            
            if response.status_code == 200:
                result = response.json()
                if result.get('status') == 'success':
                    model_id = result.get('payload', {}).get('id')
                    self.logger.info(f"Created new {device_type} model: {model_name} (ID: {model_id})")
                    return model_id
            
            self.logger.error(f"Failed to create model: {response.text}")
            return None
            
        except Exception as e:
            self.logger.error(f"Error creating model for device type: {e}")
            return None
    
    def get_or_create_manufacturer(self, manufacturer_name: str) -> Optional[int]:
        """Get existing manufacturer or create new one."""
        try:
            # Search for existing manufacturer
            response = self.session.get(
                f"{self.config['snipeit']['base_url']}/api/v1/manufacturers",
                timeout=self.config['snipeit']['timeout']
            )
            
            if response.status_code == 200:
                data = response.json()
                manufacturers = data.get('rows', [])
                
                for manufacturer in manufacturers:
                    if manufacturer.get('name', '').lower() == manufacturer_name.lower():
                        self.logger.info(f"Found existing manufacturer: {manufacturer_name} (ID: {manufacturer['id']})")
                        return manufacturer['id']
            
            # Create new manufacturer
            manufacturer_data = {'name': manufacturer_name}
            response = self.session.post(
                f"{self.config['snipeit']['base_url']}/api/v1/manufacturers",
                json=manufacturer_data,
                timeout=self.config['snipeit']['timeout']
            )
            
            if response.status_code == 200:
                result = response.json()
                if result.get('status') == 'success':
                    manufacturer_id = result.get('payload', {}).get('id')
                    self.logger.info(f"Created manufacturer: {manufacturer_name} (ID: {manufacturer_id})")
                    return manufacturer_id
                else:
                    # If creation failed due to duplicate, try to find it again
                    self.logger.warning(f"Manufacturer creation failed, searching again: {result.get('messages', 'Unknown error')}")
                    response = self.session.get(
                        f"{self.config['snipeit']['base_url']}/api/v1/manufacturers",
                        timeout=self.config['snipeit']['timeout']
                    )
                    if response.status_code == 200:
                        data = response.json()
                        manufacturers = data.get('rows', [])
                        for manufacturer in manufacturers:
                            if manufacturer.get('name', '').lower() == manufacturer_name.lower():
                                self.logger.info(f"Found manufacturer after failed creation: {manufacturer_name} (ID: {manufacturer['id']})")
                                return manufacturer['id']
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error getting/creating manufacturer: {e}")
            return None
    
    def get_or_create_category(self, category_name: str) -> Optional[int]:
        """Get existing category or create new one."""
        try:
            # Search for existing category
            response = self.session.get(
                f"{self.config['snipeit']['base_url']}/api/v1/categories",
                timeout=self.config['snipeit']['timeout']
            )
            
            if response.status_code == 200:
                data = response.json()
                categories = data.get('rows', [])
                
                for category in categories:
                    if (category.get('name', '').lower() == category_name.lower() and 
                        category.get('category_type', '') == 'Asset'):
                        self.logger.info(f"Found existing category: {category_name} (ID: {category['id']})")
                        return category['id']
            
            # Create new category
            category_data = {
                'name': category_name,
                'category_type': 'asset'
            }
            response = self.session.post(
                f"{self.config['snipeit']['base_url']}/api/v1/categories",
                json=category_data,
                timeout=self.config['snipeit']['timeout']
            )
            
            if response.status_code == 200:
                result = response.json()
                if result.get('status') == 'success':
                    category_id = result.get('payload', {}).get('id')
                    self.logger.info(f"Created category: {category_name} (ID: {category_id})")
                    return category_id
                else:
                    # If creation failed due to duplicate, try to find it again
                    self.logger.warning(f"Category creation failed, searching again: {result.get('messages', 'Unknown error')}")
                    response = self.session.get(
                        f"{self.config['snipeit']['base_url']}/api/v1/categories",
                        timeout=self.config['snipeit']['timeout']
                    )
                    if response.status_code == 200:
                        data = response.json()
                        categories = data.get('rows', [])
                        for category in categories:
                            if (category.get('name', '').lower() == category_name.lower() and 
                                category.get('category_type', '') == 'Asset'):
                                self.logger.info(f"Found category after failed creation: {category_name} (ID: {category['id']})")
                                return category['id']
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error getting/creating category: {e}")
            return None
    
    def create_asset(self, system_info: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Create a new asset in Snipe-IT."""
        if not self.config['asset']['auto_create']:
            self.logger.info("Asset auto-creation is disabled")
            return None
        
        # Determine device type and get appropriate model
        device_type = system_info.get('hardware', {}).get('device_type', 'desktop')
        model_id = self.get_model_for_device_type(device_type, system_info)
        
        # Create concise notes with only important information
        notes = self.create_concise_notes(system_info, device_type)
        
        asset_data = {
            'name': system_info['hostname'],
            'asset_tag': self.generate_asset_tag(),
            'serial': system_info.get('hardware', {}).get('serial_number', ''),
            'notes': notes
        }
        
        # Add model ID (required)
        if model_id:
            asset_data['model_id'] = model_id
        elif self.config['asset']['default_model_id']:
            asset_data['model_id'] = self.config['asset']['default_model_id']
        else:
            self.logger.error("No model ID available for asset creation")
            return None
            
        # Add other default values if configured
        if self.config['asset']['default_status_id']:
            asset_data['status_id'] = self.config['asset']['default_status_id']
        if self.config['asset']['default_location_id']:
            asset_data['location_id'] = self.config['asset']['default_location_id']
        if self.config['asset']['default_company_id']:
            asset_data['company_id'] = self.config['asset']['default_company_id']
        
        # Add custom fields
        for field_name, field_type in self.config['asset']['custom_fields'].items():
            if field_name == 'last_seen':
                asset_data[field_name] = datetime.now().isoformat()
            elif field_name == 'agent_version':
                asset_data[field_name] = "1.0.0"
            elif field_name == 'system_info':
                asset_data[field_name] = json.dumps(system_info)
        
        try:
            response = self.session.post(
                f"{self.config['snipeit']['base_url']}/api/v1/hardware",
                json=asset_data,
                timeout=self.config['snipeit']['timeout']
            )
            
            if response.status_code == 200:
                self.logger.info(f"Successfully created asset: {asset_data['asset_tag']}")
                return response.json()
            else:
                self.logger.error(f"Failed to create asset: {response.status_code} - {response.text}")
                
        except Exception as e:
            self.logger.error(f"Error creating asset: {e}")
        
        return None
    
    def update_asset(self, asset_id: int, system_info: Dict[str, Any]) -> bool:
        """Update an existing asset in Snipe-IT."""
        if not self.config['asset']['update_existing']:
            self.logger.info("Asset updates are disabled")
            return False
        
        device_type = system_info.get('hardware', {}).get('device_type', 'desktop')
        notes = self.create_concise_notes(system_info, device_type)
        update_data = {
            'notes': notes
        }
        
        # Add custom fields
        for field_name, field_type in self.config['asset']['custom_fields'].items():
            if field_name == 'last_seen':
                update_data[field_name] = datetime.now().isoformat()
            elif field_name == 'agent_version':
                update_data[field_name] = "1.0.0"
            elif field_name == 'system_info':
                update_data[field_name] = json.dumps(system_info)
        
        try:
            response = self.session.patch(
                f"{self.config['snipeit']['base_url']}/api/v1/hardware/{asset_id}",
                json=update_data,
                timeout=self.config['snipeit']['timeout']
            )
            
            if response.status_code == 200:
                self.logger.info(f"Successfully updated asset ID: {asset_id}")
                return True
            else:
                self.logger.error(f"Failed to update asset: {response.status_code} - {response.text}")
                
        except Exception as e:
            self.logger.error(f"Error updating asset: {e}")
        
        return False
    
    def sync_with_snipeit(self, system_info: Dict[str, Any]) -> bool:
        """Sync system information with Snipe-IT."""
        self.logger.info("Syncing with Snipe-IT...")
        
        # Find existing asset
        existing_asset = self.find_existing_asset(system_info)
        
        if existing_asset:
            # Update existing asset
            return self.update_asset(existing_asset['id'], system_info)
        else:
            # Create new asset
            created_asset = self.create_asset(system_info)
            return created_asset is not None
    
    def save_cache(self, data: Dict[str, Any]):
        """Save data to cache file."""
        try:
            cache_file = self.config['agent']['data_cache_file']
            with open(cache_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            self.logger.warning(f"Could not save cache: {e}")
    
    def load_cache(self) -> Optional[Dict[str, Any]]:
        """Load data from cache file."""
        try:
            cache_file = self.config['agent']['data_cache_file']
            if os.path.exists(cache_file):
                with open(cache_file, 'r') as f:
                    return json.load(f)
        except Exception as e:
            self.logger.warning(f"Could not load cache: {e}")
        return None
    
    def run_once(self):
        """Run the agent once."""
        self.logger.info("Starting Snipe-IT Agent run...")
        
        # Collect system information
        system_info = self.collect_system_info()
        
        # Save to cache
        self.save_cache(system_info)
        
        # Sync with Snipe-IT
        success = self.sync_with_snipeit(system_info)
        
        if success:
            self.logger.info("Agent run completed successfully")
        else:
            self.logger.error("Agent run failed")
        
        return success
    
    def run_daemon(self):
        """Run the agent as a daemon."""
        self.logger.info("Starting Snipe-IT Agent daemon...")
        
        while True:
            try:
                self.run_once()
                time.sleep(self.config['agent']['check_interval'])
            except KeyboardInterrupt:
                self.logger.info("Agent stopped by user")
                break
            except Exception as e:
                self.logger.error(f"Unexpected error in daemon: {e}")
                time.sleep(60)  # Wait 1 minute before retrying
    
    def test_system_collection(self):
        """Test system information collection without API calls."""
        print("🔍 Testing System Information Collection")
        print("=" * 50)
        
        system_info = self.collect_system_info()
        
        print(f"✓ System information collected successfully")
        print(f"  Hostname: {system_info['hostname']}")
        print(f"  Platform: {system_info['platform']}")
        print(f"  System: {system_info['system']}")
        print(f"  Release: {system_info['release']}")
        
        # Test hardware info
        if system_info['hardware']:
            print("✓ Hardware information collected")
            if 'manufacturer' in system_info['hardware']:
                print(f"  Manufacturer: {system_info['hardware']['manufacturer']}")
            if 'model' in system_info['hardware']:
                print(f"  Model: {system_info['hardware']['model']}")
            if 'serial_number' in system_info['hardware']:
                print(f"  Serial: {system_info['hardware']['serial_number']}")
            if 'device_type' in system_info['hardware']:
                print(f"  Device Type: {system_info['hardware']['device_type'].upper()}")
        
        # Test network info
        if system_info['network']:
            print("✓ Network information collected")
            print(f"  Interfaces: {len(system_info['network']['interfaces'])}")
        
        # Test storage info
        if system_info['storage']:
            print("✓ Storage information collected")
            print(f"  Disks: {len(system_info['storage']['disks'])}")
        
        # Test memory info
        if system_info['memory']:
            print("✓ Memory information collected")
            if 'virtual' in system_info['memory']:
                total_gb = system_info['memory']['virtual']['total'] / (1024**3)
                print(f"  Total Memory: {total_gb:.1f} GB")
        
        # Test CPU info
        if system_info['cpu']:
            print("✓ CPU information collected")
            print(f"  CPU Count: {system_info['cpu'].get('cpu_count', 'N/A')}")
        
        # Save collected data to file
        with open('system-info.json', 'w') as f:
            json.dump(system_info, f, indent=2)
        print("✓ System information saved to system-info.json")
        
        return system_info
    
    def test_api_connection(self):
        """Test API connection and list existing assets."""
        print("🔗 Testing Snipe-IT API Connection")
        print("=" * 50)
        
        try:
            # Test API connection
            print("Testing Snipe-IT API connection...")
            response = self.session.get(f"{self.config['snipeit']['base_url']}/api/v1/hardware")
            print(f"API Status Code: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                print(f"Total assets: {data['total']}")
                
                if data['total'] > 0:
                    print("\nAssets found:")
                    for asset in data['rows']:
                        print(f"- Asset Tag: {asset.get('asset_tag', 'N/A')}")
                        print(f"  Name: {asset.get('name', 'N/A')}")
                        print(f"  Serial: {asset.get('serial', 'N/A')}")
                        print(f"  Status: {asset.get('status_label', {}).get('name', 'N/A')}")
                        print(f"  Created: {asset.get('created_at', {}).get('formatted', 'N/A')}")
                        print()
                else:
                    print("No assets found in the system.")
                    
            else:
                print(f"API Error: {response.text}")
                
        except Exception as e:
            print(f"Error: {e}")
    
    def test_device_detection(self):
        """Test device type detection."""
        print("🔍 Testing Device Type Detection")
        print("=" * 50)
        
        system_info = self.collect_system_info()
        
        device_type = system_info.get('hardware', {}).get('device_type', 'unknown')
        manufacturer = system_info.get('hardware', {}).get('manufacturer', 'Unknown')
        model = system_info.get('hardware', {}).get('model', 'Unknown')
        hostname = system_info.get('hostname', 'Unknown')
        
        print(f"\n📱 Device Information:")
        print(f"   Hostname: {hostname}")
        print(f"   Manufacturer: {manufacturer}")
        print(f"   Model: {model}")
        print(f"   Device Type: {device_type.upper()}")
        
        # Show detection method
        if device_type == 'laptop':
            print(f"\n🔋 Detection Method: Battery detected")
            print(f"   Your {model} is correctly identified as a laptop!")
        elif device_type == 'desktop':
            print(f"\n🖥️  Detection Method: No battery found")
            print(f"   Your {model} is correctly identified as a desktop!")
        else:
            print(f"\n❓ Detection Method: Unknown")
        
        # Show what would happen in Snipe-IT
        print(f"\n🎯 Snipe-IT Integration:")
        print(f"   • Asset will be created with device type: {device_type}")
        print(f"   • Appropriate model will be selected automatically")
        print(f"   • Category will be set to: {device_type.title()}")
        
        return system_info
    
    def show_help(self):
        """Show help information."""
        print("🚀 Snipe-IT Agent - All-in-One Script")
        print("=" * 50)
        print()
        print("USAGE:")
        print("  python snipeit_agent_all.py [OPTIONS]")
        print()
        print("OPTIONS:")
        print("  --test-system     Test system information collection")
        print("  --test-api        Test API connection and list assets")
        print("  --test-device     Test device type detection")
        print("  --test-all        Run all tests")
        print("  --once            Run agent once and sync with Snipe-IT")
        print("  --daemon          Run agent continuously")
        print("  --config FILE     Use custom config file")
        print("  --help            Show this help")
        print()
        print("EXAMPLES:")
        print("  python snipeit_agent_all.py --test-system")
        print("  python snipeit_agent_all.py --test-api")
        print("  python snipeit_agent_all.py --test-device")
        print("  python snipeit_agent_all.py --test-all")
        print("  python snipeit_agent_all.py --once")
        print("  python snipeit_agent_all.py --daemon")
        print()
        print("FILES CREATED:")
        print("  system-info.json    - Complete system information")
        print("  snipeit-agent.log   - Detailed logs")
        print("  agent_cache.json    - Cached system data")


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description='Snipe-IT Agent - All-in-One Script')
    parser.add_argument('--config', default='config.json', help='Configuration file path')
    parser.add_argument('--test-system', action='store_true', help='Test system information collection')
    parser.add_argument('--test-api', action='store_true', help='Test API connection and list assets')
    parser.add_argument('--test-device', action='store_true', help='Test device type detection')
    parser.add_argument('--test-all', action='store_true', help='Run all tests')
    parser.add_argument('--once', action='store_true', help='Run once and sync with Snipe-IT')
    parser.add_argument('--daemon', action='store_true', help='Run as daemon')
    parser.add_argument('--help-full', action='store_true', help='Show detailed help')
    
    args = parser.parse_args()
    
    if args.help_full:
        agent = SnipeITAgent(args.config)
        agent.show_help()
        return
    
    agent = SnipeITAgent(args.config)
    
    if args.test_system:
        agent.test_system_collection()
    elif args.test_api:
        agent.test_api_connection()
    elif args.test_device:
        agent.test_device_detection()
    elif args.test_all:
        print("🧪 Running All Tests")
        print("=" * 50)
        agent.test_system_collection()
        print("\n" + "=" * 50)
        agent.test_api_connection()
        print("\n" + "=" * 50)
        agent.test_device_detection()
    elif args.daemon:
        agent.run_daemon()
    elif args.once:
        agent.run_once()
    else:
        # Default: show help
        agent.show_help()


if __name__ == "__main__":
    main()
