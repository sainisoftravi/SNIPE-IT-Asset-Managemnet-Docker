#!/bin/bash
echo "Snipe-IT Agent Deployment Script"
echo "================================="
echo

echo "Step 1: Installing Python dependencies..."
pip3 install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to install dependencies"
    exit 1
fi

echo
echo "Step 2: Configuration required"
echo "Please edit config.json with your Snipe-IT server details"
echo "- Set base_url to your Snipe-IT server URL"
echo "- Set api_token to your Snipe-IT API token"
echo
read -p "Press Enter to continue after editing config.json..."

echo "Step 3: Testing agent..."
python3 snipeit_agent_all.py --test-all
if [ $? -ne 0 ]; then
    echo "ERROR: Agent test failed"
    exit 1
fi

echo
echo "Step 4: Running agent once..."
python3 snipeit_agent_all.py --once
if [ $? -ne 0 ]; then
    echo "ERROR: Agent run failed"
    exit 1
fi

echo
echo "SUCCESS! Agent is working correctly."
echo
echo "To install as Linux service (run as root):"
echo "sudo ./install_linux.sh"
echo
echo "To run continuously:"
echo "python3 snipeit_agent_all.py --daemon"
echo
