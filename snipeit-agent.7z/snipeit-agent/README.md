# Snipe-IT Agent - Automated Asset Management

A comprehensive Python agent that automatically collects system information and syncs it with your Snipe-IT asset management server. This agent intelligently detects device types (desktop/laptop) and creates appropriate models and assets automatically.

## 🚀 Quick Start

### Prerequisites
- Python 3.7 or higher
- Snipe-IT server running and accessible
- API token from Snipe-IT

### Installation

1. **Install Python dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Configure the agent:**
   Edit `config.json` with your Snipe-IT server details:
   ```json
   {
     "snipeit": {
       "base_url": "http://your-snipeit-server.com",
       "api_token": "your-api-token-here"
     }
   }
   ```

3. **Run the agent:**
   ```bash
   # Run once
   python snipeit_agent_all.py --once
   
   # Run continuously
   python snipeit_agent_all.py --daemon
   ```

## 📁 File Structure

```
snipeit-agent/
├── snipeit_agent_all.py    # Main all-in-one script
├── snipeit_agent.bat       # Windows batch file for easy use
├── config.json             # Configuration file
├── requirements.txt        # Python dependencies
├── install_windows.ps1     # Windows service installer
├── install_linux.sh        # Linux service installer
├── README.md               # This documentation
└── SOLUTION_OVERVIEW.md   # Technical overview
```

## 🎯 Usage

### Command Line Options

```bash
# Test system information collection
python snipeit_agent_all.py --test-system

# Test API connection and list assets
python snipeit_agent_all.py --test-api

# Test device type detection
python snipeit_agent_all.py --test-device

# Run all tests
python snipeit_agent_all.py --test-all

# Run once and sync with Snipe-IT
python snipeit_agent_all.py --once

# Run continuously (daemon mode)
python snipeit_agent_all.py --daemon

# Use custom config file
python snipeit_agent_all.py --config custom-config.json --once
```

### Windows Batch File (Easy Use)

```bash
# Test system information collection
.\snipeit_agent.bat test-system

# Test API connection
.\snipeit_agent.bat test-api

# Test device type detection
.\snipeit_agent.bat test-device

# Run all tests
.\snipeit_agent.bat test-all

# Run once and sync
.\snipeit_agent.bat once

# Run continuously
.\snipeit_agent.bat daemon
```

## 🔧 Configuration

The `config.json` file contains all configuration options:

```json
{
  "snipeit": {
    "base_url": "http://localhost:8082",
    "api_token": "your-api-token",
    "timeout": 30,
    "retry_attempts": 3
  },
  "agent": {
    "check_interval": 3600,
    "log_level": "INFO",
    "log_file": "snipeit-agent.log",
    "data_cache_file": "agent_cache.json"
  },
  "asset": {
    "auto_create": true,
    "update_existing": true,
    "default_model_id": null,
    "default_status_id": 2,
    "default_location_id": null,
    "default_company_id": null,
    "custom_fields": {
      "last_seen": "datetime",
      "agent_version": "text",
      "system_info": "text"
    }
  },
  "collection": {
    "hardware": true,
    "software": true,
    "network": true,
    "storage": true,
    "memory": true,
    "cpu": true,
    "bios": true,
    "system": true
  }
}
```

## 🎯 Features

### ✅ **Intelligent Device Detection**
- **Automatic Classification**: Detects desktop vs laptop automatically
- **Battery Detection**: Uses battery presence to identify laptops
- **Chassis Analysis**: Analyzes system chassis information
- **Model Name Analysis**: Uses model names for classification
- **Cross-Platform**: Works on Windows, Linux, and macOS

### ✅ **Comprehensive System Information Collection**
- **Hardware Details**: Manufacturer, model, serial number, CPU, memory
- **Network Information**: Interfaces, IP addresses, hostname
- **Storage Details**: Disk usage, partitions, file systems
- **Software Information**: Running processes, system details
- **BIOS Information**: Version, manufacturer, release date

### ✅ **Smart Snipe-IT Integration**
- **Automatic Model Creation**: Creates appropriate models for device types
- **Manufacturer Management**: Creates manufacturers as needed
- **Category Management**: Creates categories (Desktop/Laptop) automatically
- **Asset Management**: Creates and updates assets seamlessly
- **Error Handling**: Robust error handling and retry logic

### ✅ **Production Ready**
- **Service Installation**: Install as Windows service or Linux daemon
- **Continuous Operation**: Runs continuously with configurable intervals
- **Logging**: Comprehensive logging with configurable levels
- **Caching**: Intelligent caching to avoid unnecessary API calls
- **Configuration**: Flexible configuration for different environments

## 🚀 Installation as Service

### Windows Service Installation
```bash
# Run as administrator
.\install_windows.ps1
```

### Linux Service Installation
```bash
# Run as root
sudo ./install_linux.sh
```

## 📊 What Gets Collected

### System Information
- Hostname and FQDN
- Operating system details
- Platform information
- Boot time and uptime

### Hardware Information
- Manufacturer and model
- Serial number
- CPU details (count, name, speed)
- Memory information (total, used, available)
- Device type (desktop/laptop)

### Network Information
- Network interfaces
- IP addresses
- MAC addresses
- Network configuration

### Storage Information
- Disk partitions
- File system types
- Storage usage
- Available space

### Software Information
- Running processes
- Python version
- System software details

## 🔍 Troubleshooting

### Common Issues

1. **"The model id field is required" Error**
   - **Solution**: The agent will automatically create models. Ensure your Snipe-IT server is accessible and the API token is valid.

2. **"No assets found" After Creation**
   - **Solution**: Check the Snipe-IT web interface. Assets are created successfully but may take a moment to appear.

3. **Device Type Detection Issues**
   - **Solution**: Run `python snipeit_agent_all.py --test-device` to see detection details.

### Debug Commands

```bash
# Test all functionality
python snipeit_agent_all.py --test-all

# Check API connection
python snipeit_agent_all.py --test-api

# Test device detection
python snipeit_agent_all.py --test-device

# Test system collection
python snipeit_agent_all.py --test-system
```

## 📝 Logs

The agent creates detailed logs in `snipeit-agent.log`:
- System information collection
- Device type detection
- API calls and responses
- Asset creation and updates
- Error messages and warnings

## 🎯 Use Cases

### **IT Asset Management**
- Automatically discover and catalog all devices
- Track hardware changes over time
- Maintain accurate asset records
- Reduce manual data entry

### **Compliance and Auditing**
- Comprehensive system information
- Detailed hardware and software inventory
- Regular updates and check-ins
- Audit trail and logging

### **Remote Management**
- Deploy to remote locations
- Centralized asset management
- Automated reporting
- Real-time asset status

## 🔧 Advanced Configuration

### Custom Fields
Add custom fields to track additional information:
```json
"custom_fields": {
  "last_seen": "datetime",
  "agent_version": "text",
  "system_info": "text",
  "department": "text",
  "location": "text"
}
```

### Collection Control
Enable/disable specific data collection:
```json
"collection": {
  "hardware": true,
  "software": false,
  "network": true,
  "storage": true,
  "memory": true,
  "cpu": true,
  "bios": false,
  "system": true
}
```

## 📞 Support

For issues and questions:
1. Check the logs in `snipeit-agent.log`
2. Run the test commands to diagnose issues
3. Verify Snipe-IT server connectivity and API token
4. Check the configuration file for correct settings

## 🎉 Success!

Your Snipe-IT agent is now ready for production use! It will:
- ✅ Automatically detect and classify devices
- ✅ Create appropriate models and categories
- ✅ Sync comprehensive system information
- ✅ Run continuously for real-time updates
- ✅ Handle errors gracefully with retry logic

The agent provides a complete solution for automated asset management with Snipe-IT! 🚀