#!/bin/bash
# Snipe-IT Agent Installation Script for Linux/macOS

set -e

echo "Installing Snipe-IT Agent..."

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed"
    echo "Please install Python 3.8 or higher"
    exit 1
fi

# Create installation directory
INSTALL_DIR="/opt/snipeit-agent"
sudo mkdir -p "$INSTALL_DIR"

# Copy files
sudo cp snipeit_agent.py "$INSTALL_DIR/"
sudo cp config.json "$INSTALL_DIR/"
sudo cp requirements.txt "$INSTALL_DIR/"

# Install Python dependencies
echo "Installing Python dependencies..."
pip3 install -r requirements.txt

# Create systemd service file
sudo tee /etc/systemd/system/snipeit-agent.service > /dev/null <<EOF
[Unit]
Description=Snipe-IT Agent
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
ExecStart=/usr/bin/python3 $INSTALL_DIR/snipeit_agent.py --daemon
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd and enable service
sudo systemctl daemon-reload
sudo systemctl enable snipeit-agent

echo "Installation completed!"
echo ""
echo "Next steps:"
echo "1. Edit $INSTALL_DIR/config.json with your Snipe-IT server details"
echo "2. Start the service with: sudo systemctl start snipeit-agent"
echo "3. Check status with: sudo systemctl status snipeit-agent"
echo "4. Check logs with: sudo journalctl -u snipeit-agent -f"
echo ""
