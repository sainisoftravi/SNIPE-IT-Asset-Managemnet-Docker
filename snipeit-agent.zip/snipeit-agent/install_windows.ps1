# Snipe-IT Agent Installation Script for Windows PowerShell

Write-Host "Installing Snipe-IT Agent..." -ForegroundColor Green

# Check if Python is installed
try {
    $pythonVersion = python --version 2>&1
    Write-Host "Found Python: $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "ERROR: Python is not installed or not in PATH" -ForegroundColor Red
    Write-Host "Please install Python 3.8 or higher from https://python.org" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

# Create installation directory
$installDir = "$env:ProgramFiles\SnipeIT-Agent"
if (!(Test-Path $installDir)) {
    New-Item -ItemType Directory -Path $installDir -Force
    Write-Host "Created installation directory: $installDir" -ForegroundColor Green
}

# Copy files
Copy-Item "snipeit_agent.py" "$installDir\" -Force
Copy-Item "config.json" "$installDir\" -Force
Copy-Item "requirements.txt" "$installDir\" -Force
Write-Host "Copied agent files to $installDir" -ForegroundColor Green

# Install Python dependencies
Write-Host "Installing Python dependencies..." -ForegroundColor Yellow
pip install -r requirements.txt

# Create Windows service using NSSM (Non-Sucking Service Manager)
Write-Host "Creating Windows service..." -ForegroundColor Yellow

# Check if NSSM is available, if not provide instructions
$nssmPath = Get-Command nssm -ErrorAction SilentlyContinue
if (!$nssmPath) {
    Write-Host "NSSM (Non-Sucking Service Manager) not found." -ForegroundColor Yellow
    Write-Host "Please download NSSM from https://nssm.cc/download" -ForegroundColor Yellow
    Write-Host "Extract nssm.exe to a folder in your PATH or run the following commands manually:" -ForegroundColor Yellow
    Write-Host "nssm install SnipeIT-Agent python $installDir\snipeit_agent.py --daemon" -ForegroundColor Cyan
    Write-Host "nssm set SnipeIT-Agent AppDirectory $installDir" -ForegroundColor Cyan
    Write-Host "nssm set SnipeIT-Agent DisplayName Snipe-IT Agent" -ForegroundColor Cyan
    Write-Host "nssm set SnipeIT-Agent Description Automatic asset management agent for Snipe-IT" -ForegroundColor Cyan
    Write-Host "nssm start SnipeIT-Agent" -ForegroundColor Cyan
} else {
    # Install service using NSSM
    nssm install SnipeIT-Agent python "$installDir\snipeit_agent.py" --daemon
    nssm set SnipeIT-Agent AppDirectory $installDir
    nssm set SnipeIT-Agent DisplayName "Snipe-IT Agent"
    nssm set SnipeIT-Agent Description "Automatic asset management agent for Snipe-IT"
    Write-Host "Service created successfully!" -ForegroundColor Green
}

Write-Host "Installation completed!" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "1. Edit $installDir\config.json with your Snipe-IT server details" -ForegroundColor White
Write-Host "2. Start the service with: sc start SnipeIT-Agent" -ForegroundColor White
Write-Host "3. Check logs in $installDir\snipeit-agent.log" -ForegroundColor White
Write-Host ""
Read-Host "Press Enter to exit"
