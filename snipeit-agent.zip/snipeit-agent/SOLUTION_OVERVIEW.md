# Snipe-IT Agent - Complete Solution

## Overview

I've created a complete Snipe-IT agent solution that automatically collects system information from client machines and syncs it with your Snipe-IT asset management server. This agent will help you maintain accurate asset records without manual intervention.

## What's Included

### Core Agent (`snipeit_agent.py`)
- **Cross-platform Python agent** that runs on Windows, Linux, and macOS
- **Comprehensive system data collection** including hardware, software, network, and system information
- **Smart asset management** that creates new assets or updates existing ones
- **Configurable data collection** with options to enable/disable specific information types
- **Robust error handling** and logging
- **Service/daemon mode** for continuous operation

### Configuration (`config.json` & `config.example.json`)
- **Flexible JSON configuration** for easy customization
- **Snipe-IT server settings** (URL, API token, timeout)
- **Agent behavior settings** (check interval, logging, caching)
- **Asset creation settings** (default values, custom fields)
- **Data collection settings** (what information to collect)

### Installation Scripts
- **Windows**: `install_windows.bat` and `install_windows.ps1`
- **Linux/macOS**: `install_linux.sh`
- **Automatic service creation** for background operation
- **Dependency management** with requirements.txt

### Testing & Deployment
- **Test script** (`test_agent.py`) to verify functionality
- **Package creator** (`create_package.py`) for easy distribution
- **Comprehensive documentation** (README.md)

## Key Features

### System Information Collected
- **Hardware**: CPU, memory, storage, network interfaces, BIOS info
- **Software**: OS details, running processes, system uptime
- **Network**: IP addresses, hostname, network configuration
- **System**: Manufacturer, model, serial numbers, boot time

### Smart Asset Management
- **Automatic discovery**: Finds existing assets by hostname or serial number
- **Auto-creation**: Creates new assets if not found (configurable)
- **Auto-updates**: Updates existing assets with latest information
- **Custom fields**: Populates custom fields with agent data

### Enterprise-Ready
- **Service mode**: Runs as Windows service or Linux systemd service
- **Configurable intervals**: Set how often to collect and sync data
- **Comprehensive logging**: Detailed logs for troubleshooting
- **Error handling**: Robust error handling with retry mechanisms
- **Security**: Uses API tokens for authentication

## Quick Start Guide

### 1. Setup Snipe-IT API Token
1. Log into your Snipe-IT instance
2. Go to User Settings → API Tokens
3. Create a new token with appropriate permissions
4. Copy the token for configuration

### 2. Configure the Agent
1. Edit `config.json`:
   ```json
   {
     "snipeit": {
       "base_url": "https://your-snipeit-server.com",
       "api_token": "your-actual-api-token"
     }
   }
   ```

### 3. Install and Run
**Windows**:
```powershell
.\install_windows.ps1
```

**Linux/macOS**:
```bash
sudo ./install_linux.sh
```

**Manual**:
```bash
pip install -r requirements.txt
python snipeit_agent.py --once  # Test run
python snipeit_agent.py --daemon  # Continuous operation
```

### 4. Verify Operation
- Check the log files for successful operation
- Verify assets appear in your Snipe-IT instance
- Monitor the agent's continuous operation

## Configuration Options

### Snipe-IT Settings
- `base_url`: Your Snipe-IT server URL
- `api_token`: Your API token
- `timeout`: Request timeout (seconds)
- `retry_attempts`: Number of retry attempts

### Agent Behavior
- `check_interval`: How often to collect data (seconds)
- `log_level`: Logging verbosity (DEBUG, INFO, WARNING, ERROR)
- `auto_create`: Automatically create new assets
- `update_existing`: Update existing assets

### Data Collection
Enable/disable collection of specific information:
- Hardware details
- Software information
- Network configuration
- Storage devices
- Memory information
- CPU details
- BIOS information

## Deployment Strategy

### For Small Environments
1. Install manually on each machine
2. Configure individually
3. Run as scheduled task or cron job

### For Enterprise Environments
1. Use the package creator to create deployment packages
2. Deploy via Group Policy (Windows) or configuration management
3. Use centralized configuration management
4. Monitor via log aggregation systems

### For Cloud/Mixed Environments
1. Deploy agent on physical machines
2. Use cloud metadata APIs for virtual machines
3. Integrate with existing monitoring solutions

## Security Considerations

- **API Token Security**: Store tokens securely and rotate regularly
- **Network Security**: Use HTTPS for Snipe-IT communication
- **File Permissions**: Restrict access to configuration files
- **Service Account**: Run with dedicated service account
- **Firewall Rules**: Ensure proper network access

## Troubleshooting

### Common Issues
1. **API Token Issues**: Verify token validity and permissions
2. **Network Connectivity**: Check firewall and DNS settings
3. **Permission Errors**: Ensure proper file and service permissions
4. **Configuration Errors**: Validate JSON configuration syntax

### Log Analysis
- Check agent log files for error messages
- Verify Snipe-IT server logs for API issues
- Use debug mode for detailed troubleshooting

## Customization

### Adding Custom Fields
1. Create custom fields in Snipe-IT
2. Update configuration to include custom field mappings
3. Modify agent code to populate custom fields

### Extending Data Collection
- Modify collection methods in `snipeit_agent.py`
- Add new system information sources
- Integrate with existing monitoring tools

## Support and Maintenance

### Regular Maintenance
- Monitor log files for errors
- Update API tokens as needed
- Review and adjust collection settings
- Update agent software periodically

### Monitoring
- Set up log monitoring for error detection
- Monitor API usage and rate limits
- Track asset creation and update success rates

## Next Steps

1. **Test the agent** on a few machines first
2. **Configure your Snipe-IT instance** with appropriate models and statuses
3. **Deploy gradually** across your environment
4. **Monitor and adjust** configuration as needed
5. **Train your team** on the new automated asset management

This solution provides you with a robust, enterprise-ready agent that will significantly reduce the manual effort required to maintain accurate asset records in your Snipe-IT instance.
